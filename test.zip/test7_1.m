a = [];
for i = 1:4
    a = [i,a];
end
a