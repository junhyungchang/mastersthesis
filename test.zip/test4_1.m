a = [];
for i = 1:4
    a(i,:) = i*ones(4,1);
end
a