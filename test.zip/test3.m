% clear
n = 2^(14);
k = @(x,y) exp(-(x-y).^2); % Gaussian covariance function
rng(7)
xtr = 6*rand([n,1])-3;
xtr = sort(xtr);
ytr = 2*rand([n,1]);

siz = 2^6;
ell = 25;
[y, t5, t6] = hodlr(k, xtr, ytr, siz, ell);