clear
d = 1;
if d == 1
    f = @(x,y) exp(-abs(x-y).^2);
else
    f = @(x,y) exp(-vecnorm(x-y).^2);
end
n = 2^10;
Lev = 1; % number of levels
k = 9; % target rank

%% Preparing data matrix
rng(5)
x = 2*rand(n,d)-1;

% k-d tree sorting
x = sortrows(x,1);

% Skeleton index in the last row of the data matrix
x = [x, ones(n,1)];
%% Recursive Skeletonization Factorization
tic
PP = [];
Qi = [];
Si = [];
BB = [];
DD = sparse(n,n);
Ski = [];
% Loop over levels
for c = 1:1
    m = n/2^Lev;
    Pis = [];
    Qinvs = [];
    Sinvs = [];
    Bs = [];
    % Loop over subdomains
    for z = 1:n/m
        % Location of block
        p1 = n-z*m;
        
        % Evaluate necessary sub-blocks
        % Aps and Aqr blocks
        if z == 1
            ind1 = 1:p1;
            ind2 = p1+1:n;
        elseif z == n/m
            ind1 = m+1:n;
            ind2 = 1:m;
        else
            ind1 = [1:p1, p1+m+1:n];
            ind2 = p1+1:p1+m;
        end
        for i = 1:length(ind1)
            if x(i, d+1) == 0
                Apsqr(i,:) = zeros(1,m);
            else
                Apsqr(i,:) = f(x(ind1(i),1:d), x(ind2,1:d));
            end
        end
        
        % Skeletonization
        [S, T] = IDQR(Apsqr, k);
        if c == Lev
            Ski = [S(1:k)+p1, Ski];
        end
        % permutation matrix for skeleton order
        SS = sparse(m,m);
        Pmt = speye(n);
        for i = 1:m
            SS(S(i), i) = 1;
        end
        Pmt(p1+1:p1+m, p1+1:p1+m) = SS;
        Apsqr = Apsqr*SS;
        Aps = Apsqr(:, 1:k);
        Asp = Aps';
        
%         % evaluate A (only for testing purposes)
%         for i = 1:n
%             A(i,:) = f(x(i,1:d), x(1:n,1:d));
%         end
%         A = A + eye(n);
%         A = Pmt'*A*Pmt;
%         App = A(ind1, ind1);
        
        % evaluate block of size m x m 
        for i = 1:m
            B(i,:) = f(x(p1+i,1:d), x(ind2,1:d));
        end
        B = SS'*(B*SS);
        B = B + eye(m);
        
        % evaluate necessary blocks from B
        Ass = B(1:k, 1:k);
        Asr = B(1:k, k+1:m);
        Ars = Asr';
        Arr = B(k+1:m, k+1:m);

        Brr = Arr - T'*Asr - Ars*T + T'*Ass*T;
        Bsr = Asr - Ass*T;
        Brs = Bsr';
        Bss = Ass - Bsr*(Brr\Brs);

        % LDL decomposition of Brr
        [L,D] = ldl(Brr);

        % Compute block LU factors
        
        Pis = [Pis, Pmt'];
%         Pi2s = [Pi2s, Pi2'];
%         tv1 = Pi2'*(Pi1'*tv);

        Qinv = speye(n);
        Qinv(p1+1:p1+k,p1+k+1:p1+m) = T;
%         tv1 = Qinv*tv1;
        Qinvs = [Qinvs, Qinv]; 
    
        S1inv = speye(n);
        S1inv(p1+k+1:p1+m,p1+k+1:p1+m) = L';
        S2inv = speye(n);
        S2inv(p1+k+1:p1+m,p1+1:p1+k) = D\(L\Brs);
        Sinv = S2inv*S1inv;
        Sinvs = [Sinvs, Sinv];
%         tv1 = S2inv*(S1inv*tv1);
        Bs = [Bs; Bss];
        DD(p1+1:p1+k,p1+1:p1+k) = Bss;
        %This will change for higher levels
        DD(p1+k+1:p1+m,p1+k+1:p1+m) = D;

        % retrieve indices of the inputs in the residual set
        pind = [1:n]*Pmt;
        rind = pind(p1+k+1:p1+m);  
        % switch skeleton index to 0 if in residual set
        x(rind, end) = zeros(length(rind), 1);

    end
    PP = [PP; Pis];
    Qi = [Qi; Qinvs];
    Si = [Si; Sinvs];
end

%% Error analysis 

% Test vector
tv = 2*rand(n,1)-1;
tv = tv/norm(tv);
tv1 = tv;
% over levels
for c = 1:1
    %over subdomains
    for z = 1:n/m
        tv1 = PP((c-1)*n+1:c*n, (z-1)*n+1:z*n)*tv1;
        tv1 = Qi((c-1)*n+1:c*n, (z-1)*n+1:z*n)*tv1;
        tv1 = Si((c-1)*n+1:c*n, (z-1)*n+1:z*n)*tv1;
    end
end

% evaluate remaining Aps using Ski
for i = 1:k
    DAps(i,:) = f(x(Ski(i),1:d), x(Ski(k+1:2*k), 1:d));
end
DD(1:k, n/2+1:n/2+k) = DAps;
DD(n/2+1:n/2+k, 1:k) = DAps';
tv1 = DD*tv1;

% over levels
for e = 1:1
    % over subdomains
    for y = n/m:-1:1
        tv1 = Si((e-1)*n+1:e*n, (y-1)*n+1:y*n)'*tv1;
        tv1 = Qi((e-1)*n+1:e*n, (y-1)*n+1:y*n)'*tv1;
        tv1 = PP((e-1)*n+1:e*n, (y-1)*n+1:y*n)'*tv1;        
    end
end
toc
tic
% Apply A to tv for testing
tv2 = zeros(n,1);
for i = 1:n
    tv2(i) = f(x(i,1:d), x(1:n,1:d))'*tv;
end
tv2 = tv2 + tv;
toc
% Spectral norm error estimate
norm(tv2 - tv1)