f = @(x,y) exp(-vecnorm(x'-y').^2);
rng 'default'
x = rand(10,2);
f(x(2,1:2), x(1:10,1:2))

